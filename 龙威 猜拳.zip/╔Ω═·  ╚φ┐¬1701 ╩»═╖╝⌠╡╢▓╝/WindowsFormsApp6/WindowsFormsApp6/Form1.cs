﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static int 胜利次数 = 0;//玩家赢的次数
        static int 游戏次数 = 0;//总共次数
        static int 平手次数 = 0;//平手次数
        private void Game(String fist)
        {
            游戏次数++;
            lbPlayer.Text = fist;
            int playerNum = WindowsFormsApp5.玩家.ShowFist(fist);
            WindowsFormsApp5.机器人 cpu = new WindowsFormsApp5.机器人();
            int cpuNum = cpu.jqr();
            lbComputer.Text = cpu.Jqr;
            WindowsFormsApp5.裁判最大.裁判 result = WindowsFormsApp5.裁判最大.WhoWin(playerNum, cpuNum);
            lbJudge.Text = result.ToString();
            lbStatistics.Text = "统计信息：\n\n1.您赢了" + 胜利次数 +
                "场比赛!\n\n" + "2.平手了" + 平手次数 + "次; \n\n" + "3.输掉了"
                + (游戏次数 - 胜利次数 - 平手次数) + "场比赛; \n\n" + "4.共进行了"
                + 游戏次数 + "场比赛!\n\n";
            if (result == WindowsFormsApp5.裁判最大.裁判.玩家赢)
            {
                胜利次数++;
                MessageBox.Show("恭喜，您已经赢了" + 胜利次数 + "场比赛！" + " 共进行了" + 游戏次数 + "场比赛！");
            }
            else if (result == WindowsFormsApp5.裁判最大.裁判.平手)
            {
                平手次数++;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.剪刀;
            String fist = "剪刀";
            Game(fist);
        }
        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.石头;
            String fist = "石头";
            Game(fist);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.布;
            String fist = "布";
            Game(fist);
        }
    }
}
