﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp5
{
    class 裁判最大
    {
        public enum 裁判
        {
            玩家赢,
            电脑赢,
            平手
        }
        public static 裁判 WhoWin(int playerNum, int computerNum)
        {
            int result = playerNum - computerNum;
            if (result == -1 || result == 2)
            {
                return 裁判.玩家赢;
            }
            else if (result == 0)
            {
                return 裁判.平手;

            }
            else
            {
                return 裁判.电脑赢;
            }

        }
    }
}
